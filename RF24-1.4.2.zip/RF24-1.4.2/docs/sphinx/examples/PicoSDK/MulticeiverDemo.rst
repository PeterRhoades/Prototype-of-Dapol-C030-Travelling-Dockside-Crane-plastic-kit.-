multiceiverDemo
====================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/multiceiverDemo.cpp
    :caption: examples_pico/multiceiverDemo.cpp
    :linenos:
